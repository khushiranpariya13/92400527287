FOR LOOP
for(i in 10:30){
  if(i %% 2 == 0){
    print(i)
  }
}
WHILE
i <- 10
while(i <= 30){
  if(i %% 2 == 0){
    print(i)
  }
  i <- i + 1
}
i <- 10
while(i <= 30){
  if(i %% 2 == 0){
    print(i)
  }
  i <- i + 1
}
Repeat
i <- 10
repeat{
  if(i > 30){
    break
  }
  if(i %% 2 == 0){
    print(i)
  }
  i <- i + 1
}
