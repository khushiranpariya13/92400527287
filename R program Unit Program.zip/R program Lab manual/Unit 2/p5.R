m1 <- matrix(1:16, nrow = 4, ncol = 4)
print(m1)
m2 <- matrix(1:9, nrow = 3, byrow = TRUE,
             dimnames = list(
               c("R1", "R2", "R3"),
               c("C1", "C2", "C3")
             ))
print(m2)