# Create vector
data <- c(1:12)
# Create array with dimensions (3 rows, 4 columns)
arr <- array(data,
             dim = c(3, 4),
             dimnames = list(
               Row = c("R1", "R2", "R3"),
               Column = c("C1", "C2", "C3", "C4")
             ))
# Display array
print(arr)
