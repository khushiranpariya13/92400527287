# Install package (run once)
install.packages("writexl")
# Load library
library(writexl)
# Write Excel file
write_xlsx(merged_emp, "employees.xlsx")