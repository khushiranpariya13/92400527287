# Read CSV file
data <- read.csv("employees.csv")
# Display data
print(data)
