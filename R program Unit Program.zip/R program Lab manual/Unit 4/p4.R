# Write CSV file
write.csv(merged_emp, "employees.csv", row.names = FALSE)