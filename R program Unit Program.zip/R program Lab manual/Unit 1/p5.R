# Take input from the user
num <- as.numeric(readline(prompt = "Enter a number: "))
# Generate multiplication table
cat("Multiplication Table of", num, "\n")
for (i in 1:10) {
  cat(num, "x", i, "=", num * i, "\n")
}
