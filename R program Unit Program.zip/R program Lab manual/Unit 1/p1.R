# help() - Get help on a function
help(mean)
# c() - Combine values into a vector
numbers <- c(10, 20, 30, 40, 50)
# print() - Display output
print(numbers)
# ls() - List objects in the current environment
ls()
# sqrt() - Square root of numbers
square_roots <- sqrt(numbers)
print(square_roots)
# seq() - Generate a sequence of numbers
sequence1 <- seq(from = 1, to = 10, by = 2)
print(sequence1)
# min() - Find minimum value
min_value <- min(numbers)
print(min_value)
# max() - Find maximum value
max_value <- max(numbers)
print(max_value)
# assign() - Assign a value to a variable using a string name
assign("x", 100)
print(x)
# rm() - Remove objects from the environment
rm(sequence1)
# Check remaining objects
ls()

