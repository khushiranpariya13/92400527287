# Take two numbers as input
num1 <- as.numeric(readline(prompt = "Enter first number: "))
num2 <- as.numeric(readline(prompt = "Enter second number: "))
# Perform arithmetic operations
cat("Addition:", num1 + num2, "\n")
cat("Subtraction:", num1 - num2, "\n")
cat("Multiplication:", num1 * num2, "\n")
# Check to avoid division by zero
if (num2 != 0) {
  cat("Division:", num1 / num2, "\n")
} else {
  cat("Division: Not possible (division by zero)\n")
}