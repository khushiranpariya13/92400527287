x <- 1:5
y <- c(10, 20, 15, 25, 30)

plot(x, y,
     type = "b",        # both line + points
     col = "blue",
     lwd = 2,
     pch = 19,
     main = "Styled Line Graph",
     xlab = "X-axis",
     ylab = "Y-axis")