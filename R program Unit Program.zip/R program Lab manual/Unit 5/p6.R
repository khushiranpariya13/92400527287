x <- 1:5
y <- c(10, 20, 15, 25, 30)

plot(x, y)                         # default
plot(x, y, col = "red")           # color
plot(x, y, pch = 19, col = "blue")# filled points