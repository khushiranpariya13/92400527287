x <- 1:5
y1 <- c(10, 20, 15, 25, 30)
y2 <- c(5, 15, 10, 20, 25)
y3 <- c(2, 10, 8, 18, 22)

plot(x, y1, type = "l", col = "red")
lines(x, y2, col = "blue", lty = 2)
lines(x, y3, col = "green", lty = 3)