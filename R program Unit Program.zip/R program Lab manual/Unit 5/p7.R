x <- 1:10
y <- c(5, 7, 8, 12, 15, 18, 20, 22, 25, 30)

plot(x, y, col = "green", pch = 16)
plot(x, y, col = "red", pch = 17)
plot(x, y, col = "blue", pch = 18)