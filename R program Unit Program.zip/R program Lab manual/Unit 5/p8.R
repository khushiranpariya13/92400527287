data <- c(10, 20, 30, 40)
labels <- c("A", "B", "C", "D")

pie(data, labels)