char="Knowledge is power"
print(class(char))
print(typeof(char))