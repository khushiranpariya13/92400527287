A = c(17,2,8,13,1,22)
B = c("jan","fab","mar","apr","may","jun")

barplot(A, names.arg = B, xlab = "month",
        ylab = "articals", col ="black",
        main = "barchart")