str(airquality)
Temperature<-airquality$Temp
hist(Temperature)

h=hist(Temperature,
       main="with breaks 20",
       xlab="temperature in dagrees fahrenheit",
       xlim=c(50,100),
       ylim=c(0,25),
       col="darkmagenta",
       breaks = 20)
text(h$mids,h$counts,labels=h$counts,adj=c(0.5,-0.5))
