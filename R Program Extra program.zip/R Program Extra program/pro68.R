v=c(19,23,11,5,16,21,32,14,19,27,39)
hist(v,xlab = "no of articals",
     col = "darkgreen",
     border = "black",xlim = c(0,50),
     ylim = c(0,4),breaks = 7)
