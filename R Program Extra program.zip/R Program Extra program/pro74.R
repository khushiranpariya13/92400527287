str(airquality)
Temperature<-airquality$Temp

h=hist(Temperature,
       main="Maximum daily temperature at LA Guardia Airport",
       xlab="temperature in dagrees fahrenheit",
       xlim=c(50,100),
       ylim=c(0,40),
       col="green",
       border = "brown",
       breaks = c(55,60,70,75,80,100))
text(h$mids,h$counts,labels=h$counts,
     adj=c(0.5,-0.5))
