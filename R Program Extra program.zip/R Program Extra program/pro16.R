n=40
o=20
p=30
if(n>o|p>o){
  print("atlest anyone conditions is true")
}
