plot(1:10, main="My Graph", xlab="The x-axis", ylab="The y axis",
     col="green",cex = 5, pch =20)