a=c(5,3,7,8,7,2,9,7,1,3,7)

b=is.element(7,a)

print(b)