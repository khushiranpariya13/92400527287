# x-axis values
x = c("a","b","c","d")
# y-axis values
y = c(2,4,6,8)
barplot(y, names.arg = x)