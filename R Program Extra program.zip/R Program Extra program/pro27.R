m=matrix(c(1,2,3,4,5,6,7,8,9),nrow = 3, ncol = 3)
print(m)

print("---------------------------------------")

m2 <- matrix(c("apple", "banana", "cherry", "orange"), nrow = 2, ncol = 2)
print(m2)

print("---------------------------------------")

print(m2[1,2])

print("---------------------------------------")

print(m2[1,])

print("---------------------------------------")

print(m2[,2])

print("---------------------------------------")

m3<-matrix(c("apple", "banana", "cherry",
           "orange","grape", "pineapple", "pear",
           "melon", "fig"), nrow = 3, ncol = 3)

print(m3[c(1,2),])

print("---------------------------------------")

m4=matrix(c(1,2,3,4,5,6),nrow = 3 ,ncol = 2)
m5=cbind(m4,c(7,8,9))

print(m5)

print("---------------------------------------")

m6=matrix(c(1,2,3,4,5,6),nrow = 2 ,ncol = 3)
m7=rbind(m4,c(7,8))

print(m7)

print("---------------------------------------")

m8=matrix(c("a","b","c","d","e","f","g","h","i"),nrow = 3 ,ncol = 3)

m8=m8[-c(1),-c(1)]

print(m8)

print("e" %in% m8)

print(dim(m8))

print(length(m8))

for (rows in 1:nrow(m8)) {
  for (columns in 1:ncol(m8)) {
    print(m8[rows, columns])
  }
}
