data <- data.frame(
  friend_id = c(1,2,3,4,5), 
  friend_name = c("samat","kanudo","pritesh","rajesh","ranjeet"),
  location = c("kolkata","delhi","bamgalore","hyderabad","chennai")
  
)
print(data)
data = subset(data,friend_id != 4)
print(data)