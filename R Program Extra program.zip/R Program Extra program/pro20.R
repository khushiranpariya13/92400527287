a=c(5,3,8,2,9,1,3,7)

x=min(a)
y=max(a)

print(x)
print(y)