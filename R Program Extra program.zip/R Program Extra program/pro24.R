name=c("s","d","m","p","k","r")
print(sort(name))