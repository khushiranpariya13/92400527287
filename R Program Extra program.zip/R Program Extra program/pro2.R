b=1
print(is.integer(b))
