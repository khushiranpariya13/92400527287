str(airquality)
Temperature<-airquality$Temp
hist(Temperature)

h=hist(Temperature,
     main="Maximum daily temperature at LA Guardia Airport",
     xlab="temperature in dagrees fahrenheit",
     xlim=c(50,100),
     ylim=c(0,40),
     col="darkmagenta")
text(h$mids,h$counts,labels=h$counts,adj=c(0.5,-0.5))
