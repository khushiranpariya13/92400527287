a=c(1,NA,2,3)

x=sum(na.rm=TRUE,a)
y=mean(na.rm=TRUE,a)
z=prod(na.rm=TRUE,a)

print(x)
print(y)
print(z)