#write a program that print multiplecation of given number
n1=as.numeric(readline(prompt = "enter a number : "))
for(i in 1:10){
  ans=n1 * i
  cat(n1 ,"*", i ,"=", ans,"\n")
}