v = c(5,10,15,20,25,30,35,40,45,50)
hist(v, xlab = "no.of articals",
     col = "green",border = "black",
     xlim = c(0,50),breaks = 10)