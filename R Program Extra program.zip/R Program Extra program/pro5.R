h=6+7i
print(class(h))
print(typeof(h))