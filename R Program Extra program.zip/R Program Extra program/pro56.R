colors = c("orange","green","yellow")
months = c("jan","feb","mar","apr","may")
regions = c("east","west","north")

values = matrix(c(2,9,3,11,9,4,8,7,3,12,5,2,8,10,11),
                nrow = 3, ncol = 5, byrow = TRUE)
barplot(values, main = "total revenue", names.arg = months,
        xlab = "month", ylab = "revenue",
        col = colors, beside = TRUE)

legend("topleft",regions,cex = 0.7, fill = colors)