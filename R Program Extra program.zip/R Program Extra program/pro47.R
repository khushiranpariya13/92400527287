Products <- data.frame(
  Product_ID = c(101, 102, 103),
  Product_Name = c("T-Shirt", "Jeans", "Shoes"),
  Price = c(15.99, 29.99, 49.99),
  Stock = c(50, 30, 25)
)
cat("Existing dataframe (Products):\n")
print(Products)
New_Product <- c(104, "Sunglasses", 39.99, 40)
Products <- rbind(Products, New_Product)
cat("\nUpdated dataframe after adding a new product:\n")
print(Products)