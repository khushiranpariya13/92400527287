df1 <- data.frame(
  Name = c("Alice", "Bob"),
  Age = c(25, 30),
  Score = c(80, 75)
)
df2 <- data.frame(
  Name = c("Charlie", "David"),
  Age = c(28, 35),
  Score = c(90, 85)
)
cat("Dataframe 1:\n")
print(df1)
cat("\nDataframe 2:\n")
print(df2)
combined_df <- rbind(df1, df2)
cat("\nCombined Dataframe:\n")
print(combined_df)