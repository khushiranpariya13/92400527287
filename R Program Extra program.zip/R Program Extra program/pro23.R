a=c(5,3,7,8,7,2,9,7,1,3,7)

print("a=c(5,3,7,8,7,2,9,7,1,3,7)")

no  <- readline(prompt = "Enter your no: ")

no <- as.numeric(no)

count=sum(a==no)

print(count)