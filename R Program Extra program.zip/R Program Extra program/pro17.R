r=c(1,2,3)
s=c(4,5,6)

print(r+s)