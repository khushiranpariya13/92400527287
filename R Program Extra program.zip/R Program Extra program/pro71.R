str(airquality)
Temperature<-airquality$Temp
h=hist(Temperature)
print(h)
