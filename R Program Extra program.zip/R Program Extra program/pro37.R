n=as.numeric(readline(prompt = "enter a value : "))

if(n<=1){
  cat(n,"is not a prime number \n")
}else{
  is_prime=TRUE
  for(i in 2:sqrt(n)){
    if(n %% i == 0){
      is_prime=FALSE
      break
    }
  }
  if(is_prime){
    cat(n,"is a prime number \n")
  }else{
    cat(n,"is not a prime number \n") 
  }
}