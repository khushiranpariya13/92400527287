x = c(7, 4, 3, 9, 1.2, -4, -5, -8, 6, NA)

print(sort(x))

print(sort(x, decreasing = TRUE))

print(sort(x, na.last = TRUE))