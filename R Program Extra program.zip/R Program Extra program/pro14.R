m=50

if(m>10){
  print("avove ten")
  if(m>20){
    print("avove twenty")
  }else{
    print("it is between 10 to 20")
  }
}else{
  print("it is less them 10")
}